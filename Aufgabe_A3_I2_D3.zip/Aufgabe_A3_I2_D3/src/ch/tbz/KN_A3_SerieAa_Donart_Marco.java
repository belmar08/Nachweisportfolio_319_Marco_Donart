public class KN_A3_SerieAa_Donart_Marco {
    public static void main(String[] args) {
        // Custom string input
        String str = "DieserStringwirdsortiert";

        // Converting string into an array for computation
        char arr[] = str.toCharArray(); // Convert to static array

        int i = 0; // Sort starts at the beginning
        while (i < arr.length) { // outer loop
            int j = i + 1; // j is next character in row
            while (j < arr.length) { // inner loop i till the end
                if (arr[j] < arr[i]) {
                    swap(arr, i, j); // Aufruf der neuen Tausch-Funktion
                }
                j += 1; // get next character to compare
            }
            i += 1; // get next character to sort
        }

        // Output sorted Array
        System.out.println(arr);
    }

    // Neue Swap-Funktion für den Tausch-Algorithmus (Zeilen 26-28)
    public static void swap(char[] arr, int i, int j) {
        char temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}