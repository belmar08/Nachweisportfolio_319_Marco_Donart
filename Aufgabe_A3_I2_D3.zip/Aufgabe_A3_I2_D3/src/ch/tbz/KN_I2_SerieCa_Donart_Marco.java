package ch.tbz;

import static ch.tbz.lib.Input.*;    // System-IO Library
import static java.lang.System.out;       // Input-Funktionen wie inputInt()

public class KN_I2_SerieCa_Donart_Marco {

    // Hauptprogramm
    public static void main(String[] args) {

        // Titel
        out.println("Vergleich von drei Zahlen");

        // Schleife, die so lange läuft, bis alle drei Zahlen verschieden sind
        while (true) {
            // Eingabe der drei Zahlen mit Validierung
            int num1 = inputInt("Gib die erste Zahl ein:");
            int num2 = inputInt("Gib die zweite Zahl ein:");
            int num3 = inputInt("Gib die dritte Zahl ein:");

            // Überprüfen, ob alle drei Zahlen verschieden sind
            if (num1 != num2 && num1 != num3 && num2 != num3) {
                out.println("Alle Zahlen sind verschieden!");
                break;  // Schleife beenden, wenn alle Zahlen verschieden sind
            } else {
                out.println("Die Zahlen sind nicht verschieden. Versuche es erneut.");
            }
        }

        // Programm beendet
        out.println("Das Programm wurde beendet.");
    }
}
