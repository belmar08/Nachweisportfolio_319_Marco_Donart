public class KN_D3_SerieBa_Donart_Marco {

  // 8x8 Schachbrett
  static char[][] brett = new char[8][8];

  public static void main(String[] args) {
      // Schachbrett initialisieren
      initialisieren();

      System.out.println("Initiales Schachbrett:");
      ausgeben();

      // Zwei Springer ziehen (Rössli)
      System.out.println("\nZug 1: Weisser Springer von b1 nach c3");
      bewegeFigur(7, 1, 5, 2); // b1 -> c3
      ausgeben();

      System.out.println("\nZug 2: Schwarzer Springer von g8 nach f6");
      bewegeFigur(0, 6, 2, 5); // g8 -> f6
      ausgeben();
  }

  static void initialisieren() {
      // Leeres Brett mit '.' füllen
      for (int i = 0; i < 8; i++) {
          for (int j = 0; j < 8; j++) {
              brett[i][j] = '.';
          }
      }

      // Figuren in Kleinbuchstaben für Weiss, Grossbuchstaben für Schwarz
      // Reihe 1 (Weiss, unten): Turm, Springer, Läufer, Dame, König, Läufer, Springer, Turm
      brett[7] = new char[] { 't', 's', 'l', 'd', 'k', 'l', 's', 't' };

      // Reihe 2 (Weiss Bauern)
      for (int i = 0; i < 8; i++) {
          brett[6][i] = 'b';
      }

      // Reihe 7 (Schwarz Bauern)
      for (int i = 0; i < 8; i++) {
          brett[1][i] = 'B';
      }

      // Reihe 8 (Schwarz, oben): Turm, Springer, Läufer, Dame, König, Läufer, Springer, Turm
      brett[0] = new char[] { 'T', 'S', 'L', 'D', 'K', 'L', 'S', 'T' };
  }

  static void ausgeben() {
      for (int i = 0; i < 8; i++) {
          for (int j = 0; j < 8; j++) {
              System.out.print(brett[i][j] + " ");
          }
          System.out.println();
      }
  }

  static void bewegeFigur(int vonZeile, int vonSpalte, int nachZeile, int nachSpalte) {
      brett[nachZeile][nachSpalte] = brett[vonZeile][vonSpalte];
      brett[vonZeile][vonSpalte] = '.';
  }
}
