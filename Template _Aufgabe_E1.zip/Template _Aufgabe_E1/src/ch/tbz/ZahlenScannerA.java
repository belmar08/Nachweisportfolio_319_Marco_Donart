// Package-Definition
package ch.tbz;

// Importieren der benötigten Bibliotheken
import java.util.Scanner;

public class ZahlenScannerA {
    public static void main(String[] args) {
        // Scanner für die Eingabe erstellen
        Scanner scan = new Scanner(System.in);

        // Variable für die Eingabe deklarieren
        int input;

        // Benutzeraufforderung zur Eingabe
        System.out.println("Geben Sie eine Zahl zwischen 2 und 6 ein:");

        // Einlesen der Nutzereingabe
        input = scan.nextInt();

        // Überprüfung, ob die Eingabe im gültigen Bereich liegt
        if (input >= 2 && input <= 6) {
            int zaehler = 0; // Zählvariable initialisieren

            // Schleife von -5 bis 4 (inklusive)
            for (int i = -5; i < 5; i++) {
                zaehler = zaehler + i + input; // Berechnung
                System.out.println(zaehler); // Ausgabe des Zählerwerts5
            }

        } else {
            // Falls die Eingabe ungültig ist
            System.err.println("Achtung, falsche Eingabe!");
        }

        // Abschlussmeldung
        System.out.println("und fertig!");

        // Scanner schließen, um Ressourcen zu schonen
        scan.close();
    }
}
